from joblib import  load
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
LinearReg = load("python/model/LinearReg_w.joblib")
to_predict =  pd.read_csv("python/input.csv").T
if(len(to_predict.columns)<2044):
    print("Error;1;csv does not contain enough data")
    quit()
to_predict=to_predict[to_predict.columns[:2044]]
polynomial_features= PolynomialFeatures(interaction_only=True,degree=2)
to_predict = polynomial_features.fit_transform(to_predict)
prediction = LinearReg.predict(to_predict)
rep = ""
for x in prediction[0]:
    rep =   format(x,'.2f') if (len(rep)==0) else rep + ";"+ format(x,'.2f')
print(rep)

